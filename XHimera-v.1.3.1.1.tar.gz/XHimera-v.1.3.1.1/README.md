<h2><strong>XHimera Staging Repository (Version 1.3.1.1)</strong></h2>

<p>XHimera is a cutting edge cryptocurrency, with many features not available in most other cryptocurrencies.</p>
<p>Anonymized transactions using coin mixing technology, we call it <em>Obfuscation</em>.</p>
<p>Fast transactions featuring guaranteed zero confirmation transactions, we call it <em>SwiftTX</em>.</p>

<TS language="ro_RO" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Faceți click dreapta pentru a edita adresa sau eticheta</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Creează o nouă adresă</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Nou/Nouă</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copiază adresa selectată în clipboard</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Copiază</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Șterge adresa selectată din listă</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Șterge</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportă datele din fila curentă într-un fișier</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportă</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>&amp;Închide </translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Alege adresa la care vrei să trimiți monedele</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Alege adresa la care vrei să primești monedele</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>&amp;Alege</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    </context>
<context>
    <name>AskPassphraseDialog</name>
    </context>
<context>
    <name>Bip38ToolDialog</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    </context>
<context>
    <name>BlockExplorer</name>
    </context>
<context>
    <name>ClientModel</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    </context>
<context>
    <name>EditAddressDialog</name>
    </context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>MasternodeList</name>
    </context>
<context>
    <name>MultiSendDialog</name>
    </context>
<context>
    <name>ObfuscationConfig</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    </context>
<context>
    <name>OverviewPage</name>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    </context>
<context>
    <name>ReceiveRequestDialog</name>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    </context>
<context>
    <name>SendCoinsDialog</name>
    </context>
<context>
    <name>SendCoinsEntry</name>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    </context>
<context>
    <name>SplashScreen</name>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    </context>
<context>
    <name>TransactionView</name>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Exportă</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exportă datele din fila curentă într-un fișier</translation>
    </message>
    </context>
<context>
    <name>xhimera-core</name>
    </context>
</TS>
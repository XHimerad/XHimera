<TS language="ru" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Right-click to edit address or label</source>
        <translation>Щелкните правой кнопкой мыши, чтобы изменить адрес или метку</translation>
    </message>
    <message>
        <source>Create a new address</source>
        <translation>Создать новый адрес</translation>
    </message>
    <message>
        <source>&amp;New</source>
        <translation>&amp;Новый</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Скопировать текущий выбранный адрес в буфер обмена системы</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Копировать</translation>
    </message>
    <message>
        <source>Delete the currently selected address from the list</source>
        <translation>Удалить текущий выбранный адрес из списка</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Экспортировать данные с текущей вкладки в файл</translation>
    </message>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Экспорт</translation>
    </message>
    <message>
        <source>C&amp;lose</source>
        <translation>З&amp;акрыть</translation>
    </message>
    <message>
        <source>Choose the address to send coins to</source>
        <translation>Выберите адрес для отправки монет</translation>
    </message>
    <message>
        <source>Choose the address to receive coins with</source>
        <translation>Выберите адрес для получения монет</translation>
    </message>
    <message>
        <source>C&amp;hoose</source>
        <translation>В&amp;ыберите</translation>
    </message>
    <message>
        <source>Sending addresses</source>
        <translation>Отправка адресов</translation>
    </message>
    <message>
        <source>These are your XHimera addresses for sending payments. Always check the amount and the receiving address before sending coins.</source>
        <translation>Это ваши XHimera-адреса для отправки платежей. Перед отправкой монет всегда проверяйте сумму и адрес получателя.</translation>
    </message>
    <message>
        <source>These are your XHimera addresses for receiving payments. It is recommended to use a new receiving address for each transaction.</source>
        <translation>Это ваши XHimera-адреса для получения платежей. Для каждой транзакции рекомендуется использовать новый адрес получения.</translation>
    </message>
    <message>
        <source>&amp;Copy Address</source>
        <translation>&amp;Копировать Адрес</translation>
    </message>
    <message>
        <source>Copy &amp;Label</source>
        <translation>Копировать &amp;Метку</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Редактировать</translation>
    </message>
    <message>
        <source>Export Address List</source>
        <translation>Экспорт списка адресов</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Ошибка экспорта</translation>
    </message>
    <message>
        <source>There was an error trying to save the address list to %1. Please try again.</source>
        <translation>Произошла ошибка при попытке сохранить список адресов в %1. Пожалуйста, попробуйте еще раз.</translation>
    </message>
</context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Passphrase Dialog</source>
        <translation>Диалоговое окно кодовой фразы</translation>
    </message>
    <message>
        <source>Enter passphrase</source>
        <translation>Введите кодовую фразу</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Новая кодовая фраза</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Повторить новую кодовую фразу</translation>
    </message>
    <message>
        <source>For anonymization and staking only</source>
        <translation>Только для анонимизации и разбивки</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Зашифровать кошелек</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Для этой операции требуется кодовая фраза вашего кошелька, чтобы разблокировать кошелек.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Разблокировать кошелек</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Для операции дешифрования вашего кошелька нужна кодовая фраза.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Расшифровать кошелек</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Изменить кодовую фразу</translation>
    </message>
    <message>
        <source>Enter the old and new passphrase to the wallet.</source>
        <translation>Введите старую и новую кодовую фразу для кошелька.</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Подтверждение шифрования кошелька</translation>
    </message>
    <message>
        <source>XHimera will close now to finish the encryption process. Remember that encrypting your wallet cannot fully protect your XHMs from being stolen by malware infecting your computer.</source>
        <translation>XHimera сейчас закроется, чтобы завершить процесс шифрования. Помните, что шифрование вашего кошелька не может полностью защитить ваши XHimera от кражи с использованием вредоносного ПО.</translation>
    </message>
    <message>
        <source>Are you sure you wish to encrypt your wallet?</source>
        <translation>Вы действительно хотите зашифровать свой кошелек?</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Кошелек зашифрован</translation>
    </message>
    <message>
        <source>IMPORTANT: Any previous backups you have made of your wallet file should be replaced with the newly generated, encrypted wallet file. For security reasons, previous backups of the unencrypted wallet file will become useless as soon as you start using the new, encrypted wallet.</source>
        <translation>ВАЖНО: все предыдущие резервные копии вашего файла кошелька должны быть заменены вновь созданным зашифрованным файлом кошелька. Из соображений безопасности предыдущие резервные копии незашифрованного файла кошелька станут бесполезными, как только вы начнете использовать новый зашифрованный кошелек.</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Сбой шифрования кошелька</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Шифрование кошелька не удалось из-за внутренней ошибки. Ваш кошелек не был зашифрован.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Введенные парольные фразы не совпадают.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Не удалось разблокировать кошелек</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>Кодовая фраза, введенная для расшифровки кошелька, была неверной.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Не удалось дешифровать кошелек</translation>
    </message>
    <message>
        <source>Wallet passphrase was successfully changed.</source>
        <translation>Кодовая фраза кошелька успешно изменена.</translation>
    </message>
    <message>
        <source>Warning: The Caps Lock key is on!</source>
        <translation>Внимание: Клавиша Caps Lock включена!</translation>
    </message>
</context>
<context>
    <name>Bip38ToolDialog</name>
    <message>
        <source>BIP 38 Tool</source>
        <translation>BIP 38 Утилита</translation>
    </message>
    <message>
        <source>&amp;BIP 38 Encrypt</source>
        <translation>&amp;BIP 38 Шифрование</translation>
    </message>
    <message>
        <source>Address:</source>
        <translation>Адрес:</translation>
    </message>
    <message>
        <source>The XHimera address to sign the message with</source>
        <translation>Адрес XHimera для подписи сообщения с помощью</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Выбрать ранее использованный адрес</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Вставить адрес из буфера обмена</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Passphrase: </source>
        <translation>Кодовая фраза:</translation>
    </message>
    <message>
        <source>Encrypted Key:</source>
        <translation>Зашифрованный ключ:</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Копировать текущую подпись в системный буфер обмена</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this XHimera address</source>
        <translation>Подпишите сообщение, чтобы подтвердить свой адрес XHimera</translation>
    </message>
    <message>
        <source>Encrypt &amp;Key</source>
        <translation>Зашифровать &amp;Ключ</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Сбросить все поля сообщений</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Очистить &amp;Все</translation>
    </message>
    <message>
        <source>&amp;BIP 38 Decrypt</source>
        <translation>&amp;BIP 38 Дешифрование</translation>
    </message>
    <message>
        <source>Enter the BIP 38 encrypted private key. Enter the passphrase in the middle box. Click Decrypt Key to compute the private key. After the key is decrypted, clicking 'Import Address' will add this private key to the wallet.</source>
        <translation>Введите зашифрованный с помощью BIP 38 секретный ключ. Введите секретную фразу в среднем окне. Нажмите Дешифровать Ключ чтобы создать секретный ключ. Нажав на Импортировать Адрес после дешифровки, вы добавите секретный ключ к кошельку.</translation>
    </message>
    <message>
        <source>Decrypt &amp;Key</source>
        <translation>Дешифровать &amp;Ключ</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Сбросить все поля подтверждения</translation>
    </message>
    <message>
        <source>Decrypted Key:</source>
        <translation>Дешифрованный Ключ</translation>
    </message>
    <message>
        <source>Import Address</source>
        <translation>Импортировать Адрес</translation>
    </message>
    <message>
        <source>Click "Decrypt Key" to compute key</source>
        <translation>Нажмите "Дешифровать Ключ" для генерации ключа</translation>
    </message>
    <message>
        <source>The entered passphrase is invalid. </source>
        <translation>Неправильно введена кодовая фраза.</translation>
    </message>
    <message>
        <source>Allowed: 0-9,a-z,A-Z,</source>
        <translation>Допускается: 0-9,a-z,A-Z,</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Неправильно введен адрес.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Пожалуйста, проверьте адрес и попробуйте снова.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Введенный адрес не связан с ключом.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Снятие блокировки кошелька было отменено.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Персональный ключ для введенного адреса недоступен.</translation>
    </message>
    <message>
        <source>Failed to decrypt.</source>
        <translation>Не удалось дешифровать.</translation>
    </message>
    <message>
        <source>Please check the key and passphrase and try again.</source>
        <translation>Пожалуйста, проверьте ключ и кодовую фразу и попробуйте снова.</translation>
    </message>
    <message>
        <source>Data Not Valid.</source>
        <translation>Данные недействительны.</translation>
    </message>
    <message>
        <source>Please try again.</source>
        <translation>Пожалуйста, попробуйте снова.</translation>
    </message>
    <message>
        <source>Please wait while key is imported</source>
        <translation>Пожалуйста, дождитесь импортирования ключа</translation>
    </message>
    <message>
        <source>Key Already Held By Wallet</source>
        <translation>Ключ уже используется кошельком</translation>
    </message>
    <message>
        <source>Error Adding Key To Wallet</source>
        <translation>Ошибка при добавлении ключа к кошельку</translation>
    </message>
    <message>
        <source>Successfully Added Private Key To Wallet</source>
        <translation>Персональный ключ успешно добавлен к кошельку</translation>
    </message>
</context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Wallet</source>
        <translation>Кошелек</translation>
    </message>
    <message>
        <source>Node</source>
        <translation>Узел</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Обзор</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Общий обзор кошелька</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Отправить</translation>
    </message>
    <message>
        <source>&amp;Receive</source>
        <translation>&amp;Получить</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Транзакции</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Просмотр истории транзакций</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>В&amp;ыход</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Завершить работу</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>О &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Показать информацию о Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Опции...</translation>
    </message>
    <message>
        <source>&amp;Show / Hide</source>
        <translation>&amp;Показать / Скрыть</translation>
    </message>
    <message>
        <source>Show or hide the main Window</source>
        <translation>Показать или скрыть основное Окно</translation>
    </message>
    <message>
        <source>&amp;Encrypt Wallet...</source>
        <translation>&amp;Зашифровать кошелек...</translation>
    </message>
    <message>
        <source>Encrypt the private keys that belong to your wallet</source>
        <translation>Зашифровать личные ключи, принадлежащие вашему кошельку</translation>
    </message>
    <message>
        <source>&amp;Backup Wallet...</source>
        <translation>&amp;Резервная копия кошелька...</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Сделать резервную копию кошелька в другом месте</translation>
    </message>
    <message>
        <source>&amp;Change Passphrase...</source>
        <translation>&amp;Изменить кодовую фразу</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Изменение кодовой фразы, используемой для шифрования кошелька</translation>
    </message>
    <message>
        <source>&amp;Unlock Wallet...</source>
        <translation>&amp;Разблокировать кошелек...</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Снятие блокировки кошелька</translation>
    </message>
    <message>
        <source>&amp;Lock Wallet</source>
        <translation>&amp;Блокировка кошелька</translation>
    </message>
    <message>
        <source>Sign &amp;message...</source>
        <translation>Подписать &amp;сообщение...</translation>
    </message>
    <message>
        <source>&amp;Verify message...</source>
        <translation>&amp;Проверить сообщение...</translation>
    </message>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <source>Show diagnostic information</source>
        <translation>Показать диагностическую информацию</translation>
    </message>
    <message>
        <source>&amp;Debug console</source>
        <translation>&amp;Консоль отладки</translation>
    </message>
    <message>
        <source>Open debugging console</source>
        <translation>Открыть консоль отладки</translation>
    </message>
    <message>
        <source>&amp;Network Monitor</source>
        <translation>&amp;Сетевой монитор</translation>
    </message>
    <message>
        <source>Show network monitor</source>
        <translation>Показать сетевой монитор</translation>
    </message>
    <message>
        <source>&amp;Peers list</source>
        <translation>&amp;Список пиров</translation>
    </message>
    <message>
        <source>Show peers info</source>
        <translation>Показать информацию о пирах</translation>
    </message>
    <message>
        <source>Wallet &amp;Repair</source>
        <translation>Ремонт &amp;кошелька</translation>
    </message>
    <message>
        <source>Show wallet repair options</source>
        <translation>Показать варианты восстановления кошелька</translation>
    </message>
    <message>
        <source>Open configuration file</source>
        <translation>Открыть файл настроек</translation>
    </message>
    <message>
        <source>Show Automatic &amp;Backups</source>
        <translation>Показать автоматические &amp;резервные копии</translation>
    </message>
    <message>
        <source>Show automatically created wallet backups</source>
        <translation>Показать автоматически созданные резервные копии кошелька</translation>
    </message>
    <message>
        <source>&amp;Sending addresses...</source>
        <translation>&amp;Адреса отправки...</translation>
    </message>
    <message>
        <source>&amp;Receiving addresses...</source>
        <translation>&amp;Адреса получения...</translation>
    </message>
    <message>
        <source>Open &amp;URI...</source>
        <translation>Открыть &amp;URI</translation>
    </message>
    <message>
        <source>&amp;Command-line options</source>
        <translation>&amp;Параметры командной строки</translation>
    </message>
    <message numerus="yes">
        <source>Processed %n blocks of transaction history.</source>
        <translation><numerusform>Обработан %n блок истории транзакций</numerusform><numerusform>Обработано %n блоков истории транзакций</numerusform><numerusform>Обработано %n блоков истории транзакций</numerusform><numerusform>Обработано %n блоков истории транзакций</numerusform></translation>
    </message>
    <message>
        <source>Synchronizing additional data: %p%</source>
        <translation>Синхронизация дополнительных данных: %p%</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Файл</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Инструменты</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Помощь</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Панель вкладок</translation>
    </message>
    <message>
        <source>XHimera Core</source>
        <translation>XHimera Core</translation>
    </message>
    <message>
        <source>Send coins to a XHimera address</source>
        <translation>Отправить монеты на XHimera адрес</translation>
    </message>
    <message>
        <source>Request payments (generates QR codes and xhimera: URIs)</source>
        <translation>Запросить платежи (генерирует QR-код и XHimera: URI)</translation>
    </message>
    <message>
        <source>&amp;Masternodes</source>
        <translation>&amp;Мастерноды</translation>
    </message>
    <message>
        <source>Browse masternodes</source>
        <translation>Обзор мастернод</translation>
    </message>
    <message>
        <source>&amp;About XHimera Core</source>
        <translation>&amp;О XHimera Core</translation>
    </message>
    <message>
        <source>Show information about XHimera Core</source>
        <translation>Показать информацию о XHimera Core</translation>
    </message>
    <message>
        <source>Modify configuration options for XHimera</source>
        <translation>Изменение параметров конфигурации XHimera</translation>
    </message>
    <message>
        <source>&amp;BIP38 tool</source>
        <translation>&amp;BIP38 Утилита</translation>
    </message>
    <message>
        <source>Encrypt and decrypt private keys using a passphrase</source>
        <translation>Шифрование и дешифрование личных ключей с использованием кодовой фразы</translation>
    </message>
    <message>
        <source>&amp;MultiSend</source>
        <translation>&amp;MultiSend</translation>
    </message>
    <message>
        <source>MultiSend Settings</source>
        <translation>Настройки MultiSend</translation>
    </message>
    <message>
        <source>Open Wallet &amp;Configuration File</source>
        <translation>Открыть файл &amp;настроек кошелька</translation>
    </message>
    <message>
        <source>Open &amp;Masternode Configuration File</source>
        <translation>Открыть файл &amp;настроек мастернод</translation>
    </message>
    <message>
        <source>Open Masternode configuration file</source>
        <translation>Открыть файл настроек мастернод</translation>
    </message>
    <message>
        <source>&amp;Blockchain explorer</source>
        <translation>&amp;Обзор блокчейна</translation>
    </message>
    <message>
        <source>Block explorer window</source>
        <translation>Окно обзора блока</translation>
    </message>
    <message>
        <source>XHimera Core client</source>
        <translation>Клиент XHimera Core</translation>
    </message>
    <message numerus="yes">
        <source>%n active connection(s) to XHimera network</source>
        <translation><numerusform>%n активное подключение к сети XHimera</numerusform><numerusform>%n активных подключений к сети XHimera</numerusform><numerusform>%n активных подключений к сети XHimera</numerusform><numerusform>%n активных подключений к сети XHimera</numerusform></translation>
    </message>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Синхронизация с сетью...</translation>
    </message>
    <message>
        <source>Importing blocks from disk...</source>
        <translation>Импортирование блоков с диска...</translation>
    </message>
    <message>
        <source>Reindexing blocks on disk...</source>
        <translation>Переиндексация блоков на диске...</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>Обновление не требуется</translation>
    </message>
    <message numerus="yes">
        <source>%n hour(s)</source>
        <translation><numerusform>%n час</numerusform><numerusform>%n часа</numerusform><numerusform>%n часов</numerusform><numerusform>%n часов</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n day(s)</source>
        <translation><numerusform>%n день</numerusform><numerusform>%n дня</numerusform><numerusform>%n дней</numerusform><numerusform>%n дней</numerusform></translation>
    </message>
    <message numerus="yes">
        <source>%n week(s)</source>
        <translation><numerusform>%n неделя</numerusform><numerusform>%n недели</numerusform><numerusform>%n недель</numerusform><numerusform>%n недель</numerusform></translation>
    </message>
    <message>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message numerus="yes">
        <source>%n year(s)</source>
        <translation><numerusform>%n год</numerusform><numerusform>%n года</numerusform><numerusform>%n лет</numerusform><numerusform>%n лет</numerusform></translation>
    </message>
    <message>
        <source>%1 behind</source>
        <translation>%1 позади</translation>
    </message>
    <message>
        <source>Last received block was generated %1 ago.</source>
        <translation>Последний полученный блок был сгенерирован %1 назад</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Отправленная транзакция</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Входящая транзакция</translation>
    </message>
    <message>
        <source>Sent MultiSend transaction</source>
        <translation>Отправленная MultiSend транзакция</translation>
    </message>
    <message>
        <source>Date: %1
Amount: %2
Type: %3
Address: %4
</source>
        <translation>Дата: %1
Сумма: %2
Тип: %3
Адрес: %4
</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активно</translation>
    </message>
    <message>
        <source>Not Active</source>
        <translation>Не активно</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Кошелек &lt;b&gt;зашифрован&lt;/b&gt; и в настоящее время &lt;b&gt;разблокирован&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Кошелек &lt;b&gt;зашифрован&lt;/b&gt; и в настоящее время &lt;b&gt;заблокирован&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>BlockExplorer</name>
    <message>
        <source>Blockchain Explorer</source>
        <translation>Обзор блокчейна</translation>
    </message>
    <message>
        <source>Address / Block / Transaction</source>
        <translation>Адрес / Блок / Транзакция</translation>
    </message>
    <message>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation>Текстовая метка</translation>
    </message>
    <message>
        <source>Not all transactions will be shown. To view all transactions you need to set txindex=1 in the configuration file (xhimera.conf).</source>
        <translation>Будут показаны не все транзакции. Для отображения всех транзакций необходимо выставить txindex=1 в конфигурационном файле (xhimera.conf).</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    <message>
        <source>Network Alert</source>
        <translation>Сетевое предупреждение</translation>
    </message>
</context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байты:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Сумма:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Приоритет:</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Комиссия:</translation>
    </message>
    <message>
        <source>Coin Selection</source>
        <translation>Выбор монеты</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Пыль:</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>После комиссии:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Изменить:</translation>
    </message>
    <message>
        <source>(un)select all</source>
        <translation>выделить(снять) все</translation>
    </message>
    <message>
        <source>Tree mode</source>
        <translation>Режим древа</translation>
    </message>
    <message>
        <source>List mode</source>
        <translation>Режим списка</translation>
    </message>
    <message>
        <source>(1 locked)</source>
        <translation>(1 заблокирован)</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сумма</translation>
    </message>
    <message>
        <source>Received with label</source>
        <translation>Получено с меткой</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Confirmations</source>
        <translation>Подтверждения</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Подтверждено</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Копировать адрес</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копировать метку</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Копировать ID транзакции</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Копировать количество</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Копировать комиссию</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Копировать байты</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Копировать приоритет</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Копировать пыль</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Копировать изменение</translation>
    </message>
    <message>
        <source>Please switch to "List mode" to use this function.</source>
        <translation>Для использования этой функции перейдите в "Режим списка"</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>средний</translation>
    </message>
    <message>
        <source>yes</source>
        <translation>да</translation>
    </message>
    <message>
        <source>no</source>
        <translation>нет</translation>
    </message>
    <message>
        <source>This label turns red, if the transaction size is greater than 1000 bytes.</source>
        <translation>Этот маркер становится красным если размер транзакции превысит 1000 байт.</translation>
    </message>
    <message>
        <source>This means a fee of at least %1 per kB is required.</source>
        <translation>Это означает, что необходима комиссия в размере как минимум %1 за kB</translation>
    </message>
    <message>
        <source>Transactions with higher priority are more likely to get included into a block.</source>
        <translation>Транзакции с высоким приоритетом с большей вероятностью будут включены в блок.</translation>
    </message>
    <message>
        <source>This label turns red, if the priority is smaller than "medium".</source>
        <translation>Этот маркер становится красным если приоритет ниже, чем "средний".</translation>
    </message>
    <message>
        <source>This label turns red, if any recipient receives an amount smaller than %1.</source>
        <translation>Этот маркер становится красным если получаемая адресатом сумма меньше, чем %1</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
    <message>
        <source>change from %1 (%2)</source>
        <translation>изменить с %1 (%2)</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Изменить адрес</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Метка</translation>
    </message>
    <message>
        <source>The label associated with this address list entry</source>
        <translation>Метка, связанная с этой записью в списке адресов</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Адрес</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Новый адрес получения</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Новый адрес отправки</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Изменить адрес получения</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Изменить адрес отправки</translation>
    </message>
    <message>
        <source>The entered address "%1" is not a valid XHimera address.</source>
        <translation>Введенный адрес "%1" не является XHimera адресом.</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>Введенный адрес "%1" уже находится в записной книге.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Не удалось разблокировать кошелек.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Не удалось создать новый ключ.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    <message>
        <source>A new data directory will be created.</source>
        <translation>Будет создан новый каталог данных.</translation>
    </message>
    <message>
        <source>name</source>
        <translation>имя</translation>
    </message>
    <message>
        <source>Directory already exists. Add %1 if you intend to create a new directory here.</source>
        <translation>Данный каталог уже существует. Добавьте %1 если вы все еще хотите создать здесь новый каталог.</translation>
    </message>
    <message>
        <source>Path already exists, and is not a directory.</source>
        <translation>Путь уже существует и не является каталогом.</translation>
    </message>
    <message>
        <source>Cannot create data directory here.</source>
        <translation>Здесь невозможно создать каталог данных.</translation>
    </message>
</context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>version</source>
        <translation>версия</translation>
    </message>
    <message>
        <source>XHimera Core</source>
        <translation>XHimera Core</translation>
    </message>
    <message>
        <source>(%1-bit)</source>
        <translation>(%1-бит)</translation>
    </message>
    <message>
        <source>About XHimera Core</source>
        <translation>О XHimera Core</translation>
    </message>
    <message>
        <source>Command-line options</source>
        <translation>Параметры командной строки</translation>
    </message>
    <message>
        <source>Usage:</source>
        <translation>Применение:</translation>
    </message>
    <message>
        <source>command-line options</source>
        <translation>параметры командной строки</translation>
    </message>
    <message>
        <source>UI options</source>
        <translation>Параметры интерфейса</translation>
    </message>
    <message>
        <source>Choose data directory on startup (default: 0)</source>
        <translation>Выберите каталог данных, используемый при запуске (по умолчанию: 0)</translation>
    </message>
    <message>
        <source>Set language, for example "de_DE" (default: system locale)</source>
        <translation>Задайте язык, например "de_DE"(по умолчанию: язык системы)</translation>
    </message>
    <message>
        <source>Set SSL root certificates for payment request (default: -system-)</source>
        <translation>Задать корневой сертификат SSL для платежных запросов (по умолчанию: -system-)</translation>
    </message>
    <message>
        <source>Show splash screen on startup (default: 1)</source>
        <translation>Показывать заставку при запуске (по умолчанию: 1)</translation>
    </message>
</context>
<context>
    <name>Intro</name>
    <message>
        <source>Welcome</source>
        <translation>Добро пожаловать</translation>
    </message>
    <message>
        <source>Welcome to XHimera Core.</source>
        <translation>Добро пожаловать в XHimera Core.</translation>
    </message>
    <message>
        <source>As this is the first time the program is launched, you can choose where XHimera Core will store its data.</source>
        <translation>Поскольку это первый запуск программы, вы можете выбрать, где будут храниться данные XHimera Core.</translation>
    </message>
    <message>
        <source>XHimera Core will download and store a copy of the XHimera block chain. At least %1GB of data will be stored in this directory, and it will grow over time. The wallet will also be stored in this directory.</source>
        <translation>XHimera Core загрузит и сохранит копию цепочки блоков XHimera. Каталог будет занимать около %1GB и со временем размер будет увеличиваться. Кроме того, в этом каталоге будет храниться кошелек.</translation>
    </message>
    <message>
        <source>Use the default data directory</source>
        <translation>Использовать каталог данных по умолчанию</translation>
    </message>
    <message>
        <source>Use a custom data directory:</source>
        <translation>Использовать другой каталог данных:</translation>
    </message>
    <message>
        <source>XHimera Core</source>
        <translation>XHimera Core</translation>
    </message>
    <message>
        <source>Error: Specified data directory "%1" cannot be created.</source>
        <translation>Ошибка: Невозможно создать указанный каталог данных "%1" </translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>%1 GB of free space available</source>
        <translation>Доступно %1 GB свободного места</translation>
    </message>
    <message>
        <source>(of %1 GB needed)</source>
        <translation>(требуется %1 GB)</translation>
    </message>
</context>
<context>
    <name>MasternodeList</name>
    <message>
        <source>Form</source>
        <translation>Вид</translation>
    </message>
    <message>
        <source>My Masternodes</source>
        <translation>Мои Мастерноды</translation>
    </message>
    <message>
        <source>Note: Status of your masternodes in local wallet can potentially be slightly incorrect.&lt;br /&gt;Always wait for wallet to sync additional data and then double check from another node&lt;br /&gt;if your node should be running but you still see "MISSING" in "Status" field.</source>
        <translation>Примечание: Состояние ваших мастернод в локальном кошельке может слегка отличаться от действительности. &lt;br /&gt;Всегда дожидайтесь окончания синхронизации дополнительных данных и затем дважды проверьте с другого узла&lt;br /&gt;если ваша нода должна работать, но в окне "Состояние" пишет "НЕАКТИВНО"</translation>
    </message>
    <message>
        <source>Alias</source>
        <translation>Алиас</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation>Протокол</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>Состояние</translation>
    </message>
    <message>
        <source>Active</source>
        <translation>Активно</translation>
    </message>
    <message>
        <source>Last Seen (UTC)</source>
        <translation>Последний визит (UTC)</translation>
    </message>
    <message>
        <source>Pubkey</source>
        <translation>Публичный ключ</translation>
    </message>
    <message>
        <source>S&amp;tart alias</source>
        <translation>З&amp;апуск алиаса</translation>
    </message>
    <message>
        <source>Start &amp;all</source>
        <translation>Запустить &amp;все</translation>
    </message>
    <message>
        <source>Start &amp;MISSING</source>
        <translation>Запуск &amp;НЕАКТИВНЫХ</translation>
    </message>
    <message>
        <source>&amp;Update status</source>
        <translation>&amp;Обновить состояние</translation>
    </message>
    <message>
        <source>Status will be updated automatically in (sec):</source>
        <translation>Состояние будет автоматически обновлено через (сек):</translation>
    </message>
    <message>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <source>All Masternodes</source>
        <translation>Все Мастерноды</translation>
    </message>
    <message>
        <source>Filter List:</source>
        <translation>Список фильтров:</translation>
    </message>
    <message>
        <source>Filter masternode list</source>
        <translation>Фильтровать список мастернод</translation>
    </message>
    <message>
        <source>Node Count:</source>
        <translation>Количество нод:</translation>
    </message>
    <message>
        <source>Start alias</source>
        <translation>Запуск алиаса</translation>
    </message>
    <message>
        <source>Confirm masternode start</source>
        <translation>Подтверждение запуска мастерноды</translation>
    </message>
    <message>
        <source>Are you sure you want to start masternode %1?</source>
        <translation>Вы уверены, что хотите запустить мастерноду %1?</translation>
    </message>
    <message>
        <source>Confirm all masternodes start</source>
        <translation>Подтвердить старт всех мастернод</translation>
    </message>
    <message>
        <source>Are you sure you want to start ALL masternodes?</source>
        <translation>Вы уверены, что хотите запустить ВСЕ мастерноды?</translation>
    </message>
    <message>
        <source>Command is not available right now</source>
        <translation>Команда сейчас недоступна</translation>
    </message>
    <message>
        <source>You can't use this command until masternode list is synced</source>
        <translation>Использование этой команды невозможно пока не синхронизирован список мастернод</translation>
    </message>
    <message>
        <source>Confirm missing masternodes start</source>
        <translation>Подтверждение запуска неактивных мастернод</translation>
    </message>
    <message>
        <source>Are you sure you want to start MISSING masternodes?</source>
        <translation>Вы уверены, что хотите запустить НЕАКТИВНЫЕ мастерноды?</translation>
    </message>
</context>
<context>
    <name>MultiSendDialog</name>
    <message>
        <source>MultiSend</source>
        <translation>MultiSend</translation>
    </message>
    <message>
        <source>Enter whole numbers 1 - 100</source>
        <translation>Введите целые числа 1 - 100</translation>
    </message>
    <message>
        <source>Enter % to Give (1-100)</source>
        <translation>Введите % Передачи (1-100)</translation>
    </message>
    <message>
        <source>Enter Address to Send to</source>
        <translation>Введите адрес для отправки</translation>
    </message>
    <message>
        <source>MultiSend allows you to automatically send up to 100% of your stake or masternode reward to a list of other XHimera addresses after it matures.
To Add: enter percentage to give and XHimera address to add to the MultiSend vector.
To Delete: Enter address to delete and press delete.
MultiSend will not be activated unless you have clicked Activate</source>
        <translation>MultiSend позволяет вам автоматически отправлять до 100% вознаграждения за мастерноды и удерживание, после их созревания, на другие XHimera адреса.
Для добавления: введите передаваемый процент и XHimera адрес для добавления к вектору MultiSend.
Для удаления: введите удаляемый адрес и нажмите удалить.
MultiSend будет неактивен до тех пор, пока вы не нажмете Включить</translation>
    </message>
    <message>
        <source>Add to MultiSend Vector</source>
        <translation>Добавить к вектору MultiSend</translation>
    </message>
    <message>
        <source>Add</source>
        <translation>Добавить</translation>
    </message>
    <message>
        <source>Deactivate MultiSend</source>
        <translation>Выключить MultiSend</translation>
    </message>
    <message>
        <source>Deactivate</source>
        <translation>Выключить</translation>
    </message>
    <message>
        <source>Choose an address from the address book</source>
        <translation>Выберите адрес из адресной книги</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Percentage of stake to send</source>
        <translation>Процент от удерживания для отправки</translation>
    </message>
    <message>
        <source>Percentage:</source>
        <translation>Проценты:</translation>
    </message>
    <message>
        <source>Address to send portion of stake to</source>
        <translation>Адрес для отправки части от удерживания</translation>
    </message>
    <message>
        <source>Address:</source>
        <translation>Адрес:</translation>
    </message>
    <message>
        <source>Delete Address From MultiSend Vector</source>
        <translation>Удалить адрес из Вектора MultiSend</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <source>Activate MultiSend</source>
        <translation>Включить MultiSend</translation>
    </message>
    <message>
        <source>Activate</source>
        <translation>Включить</translation>
    </message>
    <message>
        <source>View MultiSend Vector</source>
        <translation>Посмотреть Вектор MultiSend</translation>
    </message>
    <message>
        <source>View MultiSend</source>
        <translation>Просмотр MultiSend</translation>
    </message>
    <message>
        <source>Send For Stakes</source>
        <translation>Передавать вознаграждение от удерживания</translation>
    </message>
    <message>
        <source>Send For Masternode Rewards</source>
        <translation>Передавать вознаграждение за мастерноды</translation>
    </message>
    <message>
        <source>The entered address:
</source>
        <translation>Введенный адрес:
</translation>
    </message>
    <message>
        <source> is invalid.
Please check the address and try again.</source>
        <translation>недопустим.
Пожалуйста, проверьте адрес и попробуйте снова.</translation>
    </message>
    <message>
        <source>The total amount of your MultiSend vector is over 100% of your stake reward
</source>
        <translation>Итоговое значение вектора MultiSend превышает 100% ваших вознаграждений
</translation>
    </message>
    <message>
        <source>Please Enter 1 - 100 for percent.</source>
        <translation>Введите 1 - 100 для указания процентов.</translation>
    </message>
    <message>
        <source>MultiSend Vector
</source>
        <translation>Вектор MultiSend
</translation>
    </message>
    <message>
        <source>Removed </source>
        <translation>Удалено</translation>
    </message>
    <message>
        <source>Could not locate address
</source>
        <translation>Не удалось найти адрес
</translation>
    </message>
</context>
<context>
    <name>ObfuscationConfig</name>
    <message>
        <source>Configure Obfuscation</source>
        <translation>Параметры Перемешивания</translation>
    </message>
    <message>
        <source>Basic Privacy</source>
        <translation>Базовая конфиденциальность</translation>
    </message>
    <message>
        <source>High Privacy</source>
        <translation>Повышенная конфиденциальность</translation>
    </message>
    <message>
        <source>Maximum Privacy</source>
        <translation>Максимальная конфиденциальность</translation>
    </message>
    <message>
        <source>Please select a privacy level.</source>
        <translation>Выберите уровень конфиденциальности.</translation>
    </message>
    <message>
        <source>Use 2 separate masternodes to mix funds up to 10000 XHM</source>
        <translation>Используйте 2 разные мастерноды для смешивания средств до 10000 XHM</translation>
    </message>
    <message>
        <source>Use 8 separate masternodes to mix funds up to 10000 XHM</source>
        <translation>Используйте 8 разных мастернод для смешивания средств до 10000 XHM</translation>
    </message>
    <message>
        <source>Use 16 separate masternodes</source>
        <translation>Используйте 16 разных мастернод</translation>
    </message>
    <message>
        <source>This option is the quickest and will cost about ~0.025 XHM to anonymize 10000 XHM</source>
        <translation>Этот вариант является самым быстрым и будет стоить порядка ~0.025 XHM для анонимизации 10000 XHM</translation>
    </message>
    <message>
        <source>This option is moderately fast and will cost about 0.05 XHM to anonymize 10000 XHM</source>
        <translation>Это средний по скорости вариант и он будет стоить около 0.05 XHM для анонимизации 10000 XHM</translation>
    </message>
    <message>
        <source>This is the slowest and most secure option. Using maximum anonymity will cost</source>
        <translation>Это самый медленный и безопасный вариант. Максимальная анонимность стоит</translation>
    </message>
    <message>
        <source>0.1 XHM per 10000 XHM you anonymize.</source>
        <translation>0.1 XHM за 10000 XHM которые вы собираетесь анонимизировать.</translation>
    </message>
    <message>
        <source>Obfuscation Configuration</source>
        <translation>Настройка Перемешивания</translation>
    </message>
    <message>
        <source>Obfuscation was successfully set to basic (%1 and 2 rounds). You can change this at any time by opening XHimera's configuration screen.</source>
        <translation>Перемешивание было успешно выставлено на стандартные значения (%1 и 2 цикла). Вы в любой момент можете это изменить, открыв окно настройки XHimera.</translation>
    </message>
    <message>
        <source>Obfuscation was successfully set to high (%1 and 8 rounds). You can change this at any time by opening XHimera's configuration screen.</source>
        <translation>Перемешивание было успешно выбрано как высокое (%1 и 8 циклов). Вы в любой момент можете это изменить, открыв окно настройки XHimera.</translation>
    </message>
    <message>
        <source>Obfuscation was successfully set to maximum (%1 and 16 rounds). You can change this at any time by opening XHimera's configuration screen.</source>
        <translation>Перемешивание было успешно выставлено на максимальное (%1 и 16 циклов). Вы в любой момент можете это изменить, открыв окно настройки XHimera.</translation>
    </message>
</context>
<context>
    <name>OpenURIDialog</name>
    <message>
        <source>Open URI</source>
        <translation>Открыть URI</translation>
    </message>
    <message>
        <source>Open payment request from URI or file</source>
        <translation>Запросить платеж через URI или файл</translation>
    </message>
    <message>
        <source>URI:</source>
        <translation>URI:</translation>
    </message>
    <message>
        <source>Select payment request file</source>
        <translation>Выберите файл запроса платежа</translation>
    </message>
    <message>
        <source>Select payment request file to open</source>
        <translation>Выберите файл запроса платежа чтобы его открыть</translation>
    </message>
</context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <source>&amp;Main</source>
        <translation>&amp;Основной</translation>
    </message>
    <message>
        <source>Size of &amp;database cache</source>
        <translation>Размер кэша &amp;базы данных</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <source>Number of script &amp;verification threads</source>
        <translation>Количество сценариев &amp;проверочных потоков</translation>
    </message>
    <message>
        <source>(0 = auto, &lt;0 = leave that many cores free)</source>
        <translation>(0 = авто, &lt;0 = оставить свободных ядер)</translation>
    </message>
    <message>
        <source>W&amp;allet</source>
        <translation>К&amp;ошелек</translation>
    </message>
    <message>
        <source>If you disable the spending of unconfirmed change, the change from a transaction&lt;br/&gt;cannot be used until that transaction has at least one confirmation.&lt;br/&gt;This also affects how your balance is computed.</source>
        <translation>Отключив проведение неподтвержденных изменений все изменения о транзакции &lt;br/&gt;не будут использованы пока транзакция не получит хотя бы одно подтверждение.&lt;br/&gt;Также это влияет на расчет вашего баланса.</translation>
    </message>
    <message>
        <source>Automatically open the XHimera client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Автоматически открыть клиентский порт XHimera через роутер. Ваш роутер должен поддерживать UPnP, а сам сервис должен быть включен.</translation>
    </message>
    <message>
        <source>Accept connections from outside</source>
        <translation>Принимать внешние подключения</translation>
    </message>
    <message>
        <source>Allow incoming connections</source>
        <translation>Разрешить входящие подключения</translation>
    </message>
    <message>
        <source>&amp;Connect through SOCKS5 proxy (default proxy):</source>
        <translation>&amp;Подключиться через SOCKS5 (прокси-сервер по умолчанию):</translation>
    </message>
    <message>
        <source>Expert</source>
        <translation>Эксперт</translation>
    </message>
    <message>
        <source>Automatically start XHimera after logging in to the system.</source>
        <translation>Автоматически запускать XHimera после входа в систему.</translation>
    </message>
    <message>
        <source>&amp;Start XHimera on system login</source>
        <translation>&amp;Запускать XHimera при входе в систему</translation>
    </message>
    <message>
        <source>This setting determines the amount of individual masternodes that an input will be anonymized through.&lt;br/&gt;More rounds of anonymization gives a higher degree of privacy, but also costs more in fees.</source>
        <translation>Эта настройка определяет количество мастернод, используемых для анонимизации. Чем больше циклов, тем выше уровень конфиденциальности, но не стоит забывать также об увеличивающейся комиссии.</translation>
    </message>
    <message>
        <source>Obfuscation rounds to use</source>
        <translation>Количество циклов Перемешивания</translation>
    </message>
    <message>
        <source>This amount acts as a threshold to turn off Obfuscation once it's reached.</source>
        <translation>При достижении этого значения Перемешивание будет отключено.</translation>
    </message>
    <message>
        <source>Amount of XHimera to keep anonymized</source>
        <translation>Количество XHimera, держащихся анонимизированными</translation>
    </message>
    <message>
        <source>Whether to show coin control features or not.</source>
        <translation>Показывает или скрывает особенности управления монетами.</translation>
    </message>
    <message>
        <source>Enable coin &amp;control features</source>
        <translation>Включить функции &amp;управления монет</translation>
    </message>
    <message>
        <source>Show additional tab listing all your masternodes in first sub-tab&lt;br/&gt;and all masternodes on the network in second sub-tab.</source>
        <translation>Показать список всех ваших мастернод в первой вкладке&lt;br/&gt;и всех мастернод в сети во второй вкладке.</translation>
    </message>
    <message>
        <source>Show Masternodes Tab</source>
        <translation>Показать вкладку Мастернод</translation>
    </message>
    <message>
        <source>&amp;Spend unconfirmed change</source>
        <translation>&amp;Проведение неподтвержденных изменений</translation>
    </message>
    <message>
        <source>&amp;Network</source>
        <translation>&amp;Сеть</translation>
    </message>
    <message>
        <source>The user interface language can be set here. This setting will take effect after restarting XHimera.</source>
        <translation>Здесь можно выставить язык интерфейса. Изменения вступят в силу после перезапуска XHimera.</translation>
    </message>
    <message>
        <source>Language missing or translation incomplete? Help contributing translations here:
https://www.transifex.com/xhimera-project/xhimera-project-translations</source>
        <translation>Отсутствует ваш язык или заметили незавершенный перевод? Вы можете помочь нам стать лучше:
https://www.transifex.com/xhimera-project/xhimera-project-translations</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Карта порта, использующего &amp;UPnP</translation>
    </message>
    <message>
        <source>Connect to the XHimera network through a SOCKS5 proxy.</source>
        <translation>Подключиться к сети XHimera через SOCKS5 прокси.</translation>
    </message>
    <message>
        <source>Proxy &amp;IP:</source>
        <translation>&amp;IP адрес:</translation>
    </message>
    <message>
        <source>IP address of the proxy (e.g. IPv4: 127.0.0.1 / IPv6: ::1)</source>
        <translation>IP-адрес прокси сервера (например: IPv4: 127.0.0.1 / IPv6: ::1)</translation>
    </message>
    <message>
        <source>&amp;Port:</source>
        <translation>&amp;Порт</translation>
    </message>
    <message>
        <source>Port of the proxy (e.g. 9050)</source>
        <translation>Порт прокси сервера (например: 9050)</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>&amp;Окно</translation>
    </message>
    <message>
        <source>Show only a tray icon after minimizing the window.</source>
        <translation>После сворачивания окна показывать только значок в трее.</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Свернуть в трей, а не на панель задач</translation>
    </message>
    <message>
        <source>Minimize instead of exit the application when the window is closed. When this option is enabled, the application will be closed only after selecting Quit in the menu.</source>
        <translation>Сворачивать окно при закрывании вместо выхода из приложения. При включении этой опции покинуть приложение можно только после нажатия Выйти в меню программы.</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>C&amp;ворачивать при закрытии</translation>
    </message>
    <message>
        <source>User Interface &amp;language:</source>
        <translation>&amp;Язык Интерфейса</translation>
    </message>
    <message>
        <source>User Interface Theme:</source>
        <translation>Тема Интерфейса</translation>
    </message>
    <message>
        <source>&amp;Unit to show amounts in:</source>
        <translation>В каких единицах показывать сумму:</translation>
    </message>
    <message>
        <source>Decimal digits</source>
        <translation>Десятичная разрядность</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Сумма</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>&amp;Information</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <source>Protocol</source>
        <translation>Протокол</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>Copy label</source>
        <translation>Копировать метку</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сумма</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>метка</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>метка</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сумма</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Quantity:</source>
        <translation>Количество:</translation>
    </message>
    <message>
        <source>Bytes:</source>
        <translation>Байты:</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Сумма:</translation>
    </message>
    <message>
        <source>Priority:</source>
        <translation>Приоритет:</translation>
    </message>
    <message>
        <source>medium</source>
        <translation>промежуточный</translation>
    </message>
    <message>
        <source>Fee:</source>
        <translation>Комиссия:</translation>
    </message>
    <message>
        <source>Dust:</source>
        <translation>Пыль:</translation>
    </message>
    <message>
        <source>no</source>
        <translation>нет</translation>
    </message>
    <message>
        <source>After Fee:</source>
        <translation>После комиссии:</translation>
    </message>
    <message>
        <source>Change:</source>
        <translation>Изменить:</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Очистить &amp;Все</translation>
    </message>
    <message>
        <source>Copy quantity</source>
        <translation>Копировать количество</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
    <message>
        <source>Copy fee</source>
        <translation>Копировать комиссию</translation>
    </message>
    <message>
        <source>Copy bytes</source>
        <translation>Копировать байты</translation>
    </message>
    <message>
        <source>Copy priority</source>
        <translation>Копировать приоритет</translation>
    </message>
    <message>
        <source>Copy dust</source>
        <translation>Копировать пыль</translation>
    </message>
    <message>
        <source>Copy change</source>
        <translation>Копировать изменение</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(нет метки)</translation>
    </message>
</context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>Choose previously used address</source>
        <translation>Выбрать ранее использованный адрес</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Вставить адрес из буфера обмена</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>The XHimera address to sign the message with</source>
        <translation>Адрес XHimera для подписи сообщения с помощью</translation>
    </message>
    <message>
        <source>Choose previously used address</source>
        <translation>Выбрать ранее использованный адрес</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Вставить адрес из буфера обмена</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Copy the current signature to the system clipboard</source>
        <translation>Копировать текущую подпись в системный буфер обмена</translation>
    </message>
    <message>
        <source>Sign the message to prove you own this XHimera address</source>
        <translation>Подпишите сообщение, чтобы подтвердить свой адрес XHimera</translation>
    </message>
    <message>
        <source>Reset all sign message fields</source>
        <translation>Сбросить все поля сообщений</translation>
    </message>
    <message>
        <source>Clear &amp;All</source>
        <translation>Очистить &amp;Все</translation>
    </message>
    <message>
        <source>Reset all verify message fields</source>
        <translation>Сбросить все поля подтверждения</translation>
    </message>
    <message>
        <source>The entered address is invalid.</source>
        <translation>Неправильно введен адрес.</translation>
    </message>
    <message>
        <source>Please check the address and try again.</source>
        <translation>Пожалуйста, проверьте адрес и попробуйте снова.</translation>
    </message>
    <message>
        <source>The entered address does not refer to a key.</source>
        <translation>Введенный адрес не связан с ключом.</translation>
    </message>
    <message>
        <source>Wallet unlock was cancelled.</source>
        <translation>Разблокировка кошелька была отменена.</translation>
    </message>
    <message>
        <source>Private key for the entered address is not available.</source>
        <translation>Секретный ключ для введенного адреса недоступен.</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>XHimera Core</source>
        <translation>XHimera Core</translation>
    </message>
    </context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Status</source>
        <translation>Состояние</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Сумма</translation>
    </message>
    </context>
<context>
    <name>TransactionDescDialog</name>
    </context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    </context>
<context>
    <name>TransactionView</name>
    <message>
        <source>Copy address</source>
        <translation>Копировать адрес</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Копировать метку</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Копировать сумму</translation>
    </message>
    <message>
        <source>Copy transaction ID</source>
        <translation>Копировать ID транзакции</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Подтверждено</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>метка</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <source>Exporting Failed</source>
        <translation>Ошибка экспорта</translation>
    </message>
    </context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    </context>
<context>
    <name>WalletView</name>
    <message>
        <source>&amp;Export</source>
        <translation>&amp;Экспорт</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Экспортировать данные на текущей вкладке в файл</translation>
    </message>
    </context>
<context>
    <name>xhimera-core</name>
    <message>
        <source>Block creation options:</source>
        <translation>Варианты создания блока:</translation>
    </message>
    <message>
        <source>Cannot downgrade wallet</source>
        <translation>Нельзя понизить кошелек</translation>
    </message>
    <message>
        <source>Cannot write default address</source>
        <translation>Невозможно записать адрес по умолчанию</translation>
    </message>
    <message>
        <source>Collateral not valid.</source>
        <translation>Залог недействителен.</translation>
    </message>
    <message>
        <source>Connection options:</source>
        <translation>Варианты подключения:</translation>
    </message>
    <message>
        <source>Copyright (C) 2009-%i The Bitcoin Core Developers</source>
        <translation>Copyright (C) 2009-%i Разработчики Bitcoin Core</translation>
    </message>
    <message>
        <source>Copyright (C) 2014-%i The Dash Core Developers</source>
        <translation>Copyright (C) 2014-%i Разработчики Dash Core</translation>
    </message>
    <message>
        <source>Copyright (C) 2015-%i The XHimera Core Developers</source>
        <translation>Copyright (C) 2015-%i Разработчики XHimera Core</translation>
    </message>
    <message>
        <source>Corrupted block database detected</source>
        <translation>Обнаружена поврежденная база данных блоков</translation>
    </message>
    <message>
        <source>Debugging/Testing options:</source>
        <translation>Параметры отладки / тестирования:</translation>
    </message>
    <message>
        <source>Do you want to rebuild the block database now?</source>
        <translation>Вы хотите перестроить базу данных блоков сейчас?</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Загрузка выполнена</translation>
    </message>
    <message>
        <source>Entries are full.</source>
        <translation>Записи заполнены.</translation>
    </message>
    <message>
        <source>Error initializing block database</source>
        <translation>Ошибка инициализации базы данных блоков</translation>
    </message>
    <message>
        <source>Error loading block database</source>
        <translation>Ошибка загрузки базы данных блоков</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Ошибка при загрузке wallet.dat</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Ошибка при загрузке wallet.dat: Кошелек поврежден</translation>
    </message>
    <message>
        <source>Error opening block database</source>
        <translation>Ошибка открытия базы данных блоков</translation>
    </message>
    <message>
        <source>Error reading from database, shutting down.</source>
        <translation>Ошибка чтения из базы данных, завершение работы.</translation>
    </message>
    <message>
        <source>Error recovering public key.</source>
        <translation>Ошибка при восстановлении открытого ключа.</translation>
    </message>
    <message>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <source>Error: A fatal internal error occured, see debug.log for details</source>
        <translation>Ошибка: произошла фатальная внутренняя ошибка, подробности см. В файле debug.log.</translation>
    </message>
    <message>
        <source>Error: Can't select current denominated inputs</source>
        <translation>Ошибка: невозможно выбрать текущие входы</translation>
    </message>
    <message>
        <source>Error: Disk space is low!</source>
        <translation>Ошибка. Недостаточно места на диске!</translation>
    </message>
    <message>
        <source>Error: Wallet locked, unable to create transaction!</source>
        <translation>Ошибка: кошелек заблокирован, невозможно создать транзакцию!</translation>
    </message>
    <message>
        <source>Failed to read block</source>
        <translation>Не удалось прочитать блок</translation>
    </message>
    <message>
        <source>Finalizing transaction.</source>
        <translation>Завершение транзакции.</translation>
    </message>
    <message>
        <source>Found enough users, signing ...</source>
        <translation>Нашел достаточно пользователей, подписал ...</translation>
    </message>
    <message>
        <source>Importing...</source>
        <translation>Импорт ...</translation>
    </message>
    <message>
        <source>Incompatible mode.</source>
        <translation>Несовместимый режим.</translation>
    </message>
    <message>
        <source>Incompatible version.</source>
        <translation>Несовместимая версия.</translation>
    </message>
    <message>
        <source>Incorrect or no genesis block found. Wrong datadir for network?</source>
        <translation>Неправильный или не обнаруженный блок генезиса. Неверный каталог данных для сети?</translation>
    </message>
    <message>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <source>Input is not valid.</source>
        <translation>Недопустимый ввод.</translation>
    </message>
    <message>
        <source>Insufficient funds.</source>
        <translation>Недостаточно средств.</translation>
    </message>
    <message>
        <source>Invalid private key.</source>
        <translation>Недопустимый закрытый ключ.</translation>
    </message>
    <message>
        <source>Invalid script detected.</source>
        <translation>Обнаружен неверный сценарий.</translation>
    </message>
    <message>
        <source>Last successful Obfuscation action was too recent.</source>
        <translation>Последняя успешная операция обфускации была совсем недавно.</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Загрузка адресов ...</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Загружается индекс блока ...</translation>
    </message>
    <message>
        <source>Loading budget cache...</source>
        <translation>Загрузка кэша бюджета ...</translation>
    </message>
    <message>
        <source>Loading wallet... (%3.2f %%)</source>
        <translation>Загрузка кошелька ... (%3.2f %%)</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Загрузка кошелька ...</translation>
    </message>
    <message>
        <source>Missing input transaction information.</source>
        <translation>Отсутствует входная информация о транзакции.</translation>
    </message>
    <message>
        <source>Mixing in progress...</source>
        <translation>Выполняется микширование ...</translation>
    </message>
    <message>
        <source>No funds detected in need of denominating.</source>
        <translation>Не обнаружено средств, требующих деноминации.</translation>
    </message>
    <message>
        <source>No matching denominations found for mixing.</source>
        <translation>Соответствующие наименования для смешивания не найдены.</translation>
    </message>
    <message>
        <source>Node relay options:</source>
        <translation>Варианты реле узла:</translation>
    </message>
    <message>
        <source>Non-standard public key detected.</source>
        <translation>Обнаружен нестандартный открытый ключ.</translation>
    </message>
    <message>
        <source>Not compatible with existing transactions.</source>
        <translation>Не совместим с существующими транзакциями.</translation>
    </message>
    <message>
        <source>Not enough file descriptors available.</source>
        <translation>Недостаточно доступных дескрипторов файлов.</translation>
    </message>
    <message>
        <source>Obfuscation options:</source>
        <translation>Варианты обфускации:</translation>
    </message>
    <message>
        <source>Obfuscation request complete:</source>
        <translation>Запрос об обфускации завершен:</translation>
    </message>
    <message>
        <source>Obfuscation request incomplete:</source>
        <translation>Запрос об обфускации неполный:</translation>
    </message>
    <message>
        <source>Options:</source>
        <translation>Опции:</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Пароль для подключений JSON-RPC</translation>
    </message>
    <message>
        <source>RPC server options:</source>
        <translation>Параметры сервера RPC:</translation>
    </message>
    <message>
        <source>Rescan the block chain for missing wallet transactions</source>
        <translation>Повторите сканирование цепочки блоков для пропущенных транзакций в кошельке.</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Повторное сканирование ...</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Запускать в фоновом режиме в качестве демона и принимать команды</translation>
    </message>
    <message>
        <source>Session not complete!</source>
        <translation>Сессия не завершена!</translation>
    </message>
    <message>
        <source>Session timed out.</source>
        <translation>Время сеанса истекло.</translation>
    </message>
    <message>
        <source>Signing failed.</source>
        <translation>Сбой подписи.</translation>
    </message>
    <message>
        <source>Signing transaction failed</source>
        <translation>Не удалось подписать транзакцию</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Укажите каталог данных</translation>
    </message>
    <message>
        <source>Specify wallet file (within data directory)</source>
        <translation>Укажите файл кошелька (в каталоге данных)</translation>
    </message>
    <message>
        <source>Specify your own public address</source>
        <translation>Укажите свой собственный общедоступный адрес</translation>
    </message>
    <message>
        <source>Synchronization failed</source>
        <translation>Ошибка синхронизации</translation>
    </message>
    <message>
        <source>Synchronization finished</source>
        <translation>Синхронизация завершена</translation>
    </message>
    <message>
        <source>Synchronization pending...</source>
        <translation>Ожидается синхронизация ...</translation>
    </message>
    <message>
        <source>Synchronizing budgets...</source>
        <translation>Синхронизация бюджетов ...</translation>
    </message>
    <message>
        <source>Synchronizing masternode winners...</source>
        <translation>Синхронизация мастернод победителей ...</translation>
    </message>
    <message>
        <source>Synchronizing masternodes...</source>
        <translation>Синхронизация мастернод ...</translation>
    </message>
    <message>
        <source>Synchronizing sporks...</source>
        <translation>Синхронизация спорков ...</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Это справочное сообщение</translation>
    </message>
    <message>
        <source>This is experimental software.</source>
        <translation>Это экспериментальное программное обеспечение.</translation>
    </message>
    <message>
        <source>This is intended for regression testing tools and app development.</source>
        <translation>Это предназначено для инструментов тестирования регрессии и разработки приложений.</translation>
    </message>
    <message>
        <source>Transaction amount too small</source>
        <translation>Слишком маленькая сумма транзакции</translation>
    </message>
    <message>
        <source>Transaction amounts must be positive</source>
        <translation>Суммы транзакций должны быть положительными</translation>
    </message>
    <message>
        <source>Transaction created successfully.</source>
        <translation>Транзакция создана успешно.</translation>
    </message>
    <message>
        <source>Transaction fees are too high.</source>
        <translation>Сборы за транзакцию слишком высоки.</translation>
    </message>
    <message>
        <source>Transaction not valid.</source>
        <translation>Транзакция недействительна.</translation>
    </message>
    <message>
        <source>Transaction too large</source>
        <translation>Слишком большая транзакция</translation>
    </message>
    <message>
        <source>Transmitting final transaction.</source>
        <translation>Передача окончательной транзакции.</translation>
    </message>
    <message>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    </context>
</TS>